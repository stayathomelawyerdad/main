# Changelog

All notable changes to this project will be documented in this file.
This file adheres to [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and [semantic versioning](https://semver.org/).

## [Unreleased]

- Initial repository structure and documentation.
- Added SOPs for intake workflow, task generation, and document automation.
- Added template sync scripts (Python and Apps Script).
- Added Clio helper and example configuration files.

## [1.0.0] – 2025‑08‑16

### Added

- Bootstrap commit with full repository structure and initial content.

### Security

- Established security guidelines and added SECURITY.md.

### Documentation

- Comprehensive README with structure and usage instructions.