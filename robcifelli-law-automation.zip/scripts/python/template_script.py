#!/usr/bin/env python3
"""
Template Script

Use this script as a starting point for new automation.  It demonstrates
loading configuration, logging, and making API requests.  To run it,
install dependencies listed in requirements.txt and execute:

    python3 scripts/python/template_script.py

Replace the placeholder logic in `main()` with your automation steps.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict

# Optional: import requests if you need to call external APIs
try:
    import requests  # type: ignore
except ImportError:
    requests = None  # Avoid import error if requests isn't installed


def load_config() -> Dict[str, Any]:
    """Load configuration from config/settings.json if it exists, otherwise
    return an empty dict.  Secrets should be stored in this file, which is
    ignored by Git.
    """
    config_path = Path(__file__).resolve().parents[2] / "config" / "settings.json"
    if not config_path.exists():
        logging.warning("config/settings.json not found; using empty config")
        return {}
    with config_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    """Entrypoint for the script."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    config = load_config()
    logging.info("Starting template script...")
    # Example: fetch current user from Clio API if API key provided
    clio_key = config.get("CLIO_API_KEY")
    if clio_key and requests:
        url = "https://app.clio.com/api/v4/users/who_am_i"
        headers = {"Authorization": f"Bearer {clio_key}"}
        try:
            resp = requests.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            user_info = resp.json()
            logging.info("Authenticated as %s", user_info.get("name"))
        except Exception as exc:  # pylint: disable=broad-except
            logging.error("Failed to call Clio API: %s", exc)
    else:
        logging.info("No CLIO_API_KEY configured; skipping API call")
    # TODO: add your automation logic here
    logging.info("Finished template script.")


if __name__ == "__main__":
    main()