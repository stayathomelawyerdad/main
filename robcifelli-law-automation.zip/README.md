# Rob Cifelli Law Automation Repository

This repository contains all of the automation logic, templates, and Standard Operating
Procedures (SOPs) used at the law firm of Robert A. Cifelli.  It is designed to be a
single source of truth for how the firm integrates Clio Grow, Clio Manage, Google
Workspace, Zapier, Motion, and other tools to streamline day‑to‑day operations.  All
scripts and documentation are version controlled here so that changes can be tracked,
reviewed, and rolled back as needed.

## Repository Structure

The top‑level directories are organized by purpose:

- **automations/** – Documentation and configuration for automation tools.  Each
  subfolder describes how a particular integration is implemented.  For example,
  `zapier/` contains summaries of each Zap (trigger, action, and logic), while
  `clio/` documents custom fields and naming conventions used in Clio Grow and
  Clio Manage.
- **scripts/** – Python and JavaScript scripts that extend or support the
  automations.  These scripts can be run on demand or scheduled via GitHub
  Actions.  A template script is provided to help you bootstrap new scripts.
- **SOPs/** – Markdown files that serve as Standard Operating Procedures for
  each workflow.  They explain, step by step, how to handle client intake,
  generate tasks, produce documents, and more.  When a workflow changes, the
  corresponding SOP must be updated in the same commit as any code or
  configuration changes.
- **templates/** – Versions of form letters, engagement letters, and other
  document templates used by automations.  Keeping a copy in this directory
  enables you to track changes over time.  The live versions remain in
  Google Drive or Clio Grow; this directory is a backup.
- **config/** – Configuration files such as example settings and CSV mappings.
  Real API keys and secrets should never be committed here; instead, copy
  `settings-example.json` to `settings.json` locally and fill in your secrets.
- **.github/** – GitHub configuration including automated workflows.  The
  provided workflows run lint checks on Python scripts and periodically sync
  template files from Google Drive into the `templates/` directory.

## Getting Started

1. **Clone the repository**:

   ```bash
   git clone git@github.com:<your‑account>/robcifelli-law-automation.git
   cd robcifelli-law-automation
   ```

2. **Install dependencies** for Python scripts (optional):

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Create a local config file** by copying the example:

   ```bash
   cp config/settings-example.json config/settings.json
   # then edit settings.json and add your API keys and IDs
   ```

4. **Read the SOPs** in `SOPs/` to understand the workflows.  Each SOP
   includes triggers, automated steps, and manual follow‑ups.  If you build a new
   automation, document it in a new Markdown file in this directory.

5. **Run scripts** in the `scripts/` directory as needed.  Most scripts are
   idempotent and can be run via `python scripts/python/<script_name>.py`.

## Branching and Releases

Work on new features in branches prefixed with `feature/`, bug fixes in
`fix/`, and documentation changes in `docs/`.  When a set of changes is stable,
merge it into `main` and tag a release.  Use semantic versioning for tags
(e.g. `v1.0.0`, `v1.1.0`) so that you can refer to specific states of the
repository.

## Security and Privacy

This repository is private and should never include client data or real
API keys.  Always store sensitive secrets in environment variables,
GitHub Secrets, or local untracked files.  The `config/settings-example.json`
file documents which keys are required and where to place them.

## License

This project is proprietary and intended for internal use at the law firm
of Robert A. Cifelli.  Redistribution is prohibited without express
authorization.