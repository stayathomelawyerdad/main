# Security Policy

This repository contains automation scripts and documentation for a law
office.  It is crucial to protect client confidentiality and the security
of our systems.  Please adhere to the following security practices:

- **Sensitive Data:** Never commit client data, personal information, or
  credentials to the repository.  Real API keys and secrets must be stored
  in untracked files (e.g. `config/settings.json`) or GitHub Secrets.
- **Access Control:** Repository access is limited to authorized staff.
  Do not share the repository outside the organization.  Remove access
  promptly when someone leaves the firm.
- **Two‑Factor Authentication:** All contributors must enable 2FA on
  their GitHub accounts.  This is enforced at the organization level.
- **Security Updates:** Keep dependencies up to date.  If you add new
  packages, ensure they come from trusted sources and monitor for
  vulnerabilities.
- **Incident Reporting:** If you discover a security vulnerability in this
  codebase or infrastructure, report it immediately to the firm’s
  security contact.  Do not discuss vulnerabilities publicly or with
  unauthorized personnel.

By following these guidelines, we protect our clients and maintain the
integrity of our automation systems.