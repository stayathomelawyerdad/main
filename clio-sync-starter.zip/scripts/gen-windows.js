// scripts/gen-windows.js
const fs = require('fs');
const [,, start, end] = process.argv;
function toDate(s){ return new Date(s+'T00:00:00Z'); }
function fmt(d){ return d.toISOString().slice(0,10); }
let s = toDate(start), e = toDate(end||new Date().toISOString().slice(0,10));
const out = [];
let curEnd = new Date(e);
while (curEnd >= s) {
  const curStart = new Date(curEnd);
  curStart.setMonth(curStart.getMonth()-1);
  out.push({ start: fmt(curStart), end: fmt(curEnd) });
  curEnd = new Date(curStart);
}
fs.writeFileSync('audits/windows.json', JSON.stringify(out, null, 2));
console.log('Wrote audits/windows.json with', out.length, 'windows');
