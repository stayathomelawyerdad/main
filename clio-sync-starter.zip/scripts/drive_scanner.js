// scripts/drive_scanner.js
function fetchDriveWindow(startISO, endISO, roots) {
  const results = [];
  const q = `modifiedTime >= '${startISO}T00:00:00' and modifiedTime < '${endISO}T00:00:00' and trashed = false`;
  const files = Drive.Files.list({ q, pageSize: 100, fields: 'files(id,name,mimeType,parents,modifiedTime)' }).files || [];
  const allowedRootIds = resolveRootIds(roots);
  for (const f of files) {
    if (!f.parents || !f.parents.some(p => allowedRootIds.has(p))) continue;
    const blob = DriveApp.getFileById(f.id).getBlob();
    results.push({
      src: 'drive',
      driveId: f.id,
      name: f.name,
      mime: blob.getContentType(),
      b64: Utilities.base64Encode(blob.getBytes())
    });
  }
  return results;
}
function resolveRootIds(names) {
  const set = new Set();
  (names||[]).forEach(n => {
    const it = DriveApp.getFoldersByName(n);
    if (it.hasNext()) set.add(it.next().getId());
  });
  return set;
}
