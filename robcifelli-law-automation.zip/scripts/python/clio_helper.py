#!/usr/bin/env python3
"""
clio_helper

This module provides helper functions for interacting with the Clio API.
It centralizes authentication and common operations so that individual
scripts can import and reuse them.  All functions expect a valid
configuration dictionary with a `CLIO_API_KEY` entry.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

import requests


BASE_URL = "https://app.clio.com/api/v4"


def who_am_i(config: Dict[str, Any]) -> Dict[str, Any] | None:
    """Return information about the authenticated user.

    Args:
        config: Dictionary containing at least a `CLIO_API_KEY` entry.

    Returns:
        A dictionary with user information, or None if the request fails.
    """
    api_key = config.get("CLIO_API_KEY")
    if not api_key:
        logging.error("CLIO_API_KEY missing from configuration")
        return None
    url = f"{BASE_URL}/users/who_am_i"
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:  # pylint: disable=broad-except
        logging.error("Clio who_am_i failed: %s", exc)
        return None


def get_matter(config: Dict[str, Any], matter_id: str) -> Dict[str, Any] | None:
    """Retrieve a matter by ID.

    Args:
        config: Configuration with CLIO_API_KEY.
        matter_id: The ID of the matter in Clio Manage.

    Returns:
        A dictionary with matter details, or None on failure.
    """
    api_key = config.get("CLIO_API_KEY")
    if not api_key:
        logging.error("CLIO_API_KEY missing from configuration")
        return None
    url = f"{BASE_URL}/matters/{matter_id}"
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        return resp.json().get("matter")
    except Exception as exc:  # pylint: disable=broad-except
        logging.error("Failed to fetch matter %s: %s", matter_id, exc)
        return None


# Add more helper functions as needed, such as create_matter(), create_task(), etc.
