# Contributing Guidelines

Thank you for your interest in improving this repository.  Since this project
contains sensitive automation logic for a law firm, contributions are
restricted to authorized personnel.  If you have suggestions or corrections,
follow these guidelines:

1. **Branch:** Create a branch based on `main` and give it a descriptive
   name (e.g. `feature/add-probate-workflow`).
2. **Update Documentation:** When you change code or automation logic,
   update the relevant SOP in `SOPs/`.  Changes without documentation
   updates will not be accepted.
3. **Commit Messages:** Write clear commit messages in present tense,
   indicating what you changed and why.  For example, “feat: add probate
   task automation” or “fix: correct date calculation”.
4. **Pull Request:** Open a pull request and request review from the
   automation lead.  Summarize the change, mention any new dependencies,
   and reference relevant issues.
5. **Testing:** Test your changes thoroughly.  If you add a script,
   consider adding unit tests or instructions on how to test manually.

Contributions that do not follow these guidelines may be rejected or
require revisions.  Thank you for helping us maintain a reliable
automation system.