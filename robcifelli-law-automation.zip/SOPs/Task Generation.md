# SOP: Automatic Task Generation for Matters

**Last Updated:** 2025‑08‑16

## Purpose

This SOP explains how the firm automatically generates tasks and calendar
deadlines for matters based on key dates and matter type.  Automating task
generation ensures consistency, reduces manual data entry, and helps prevent
deadlines from being missed.

## Trigger

- **Event:** A matter is created in Clio Manage or a key date is updated (e.g.
  closing date, inspection period end).
- **Automation:** A Zapier Zap or custom Clio workflow listens for matter
  creation and updates.  It triggers a Python script (`scripts/python/
  generate_tasks.py`) to compute deadlines and create tasks.

## Automated Steps

1. **Retrieve Matter Details:** The script fetches the matter’s custom
   fields via the Clio API.  These include the closing date, inspection
   period days, financing contingency, etc.  If any required dates are
   missing, the script logs a warning and stops.
2. **Calculate Deadlines:** Based on the closing date and other time
   periods, the script calculates the due dates for each task (e.g. due
   diligence, title search, final walkthrough).  A mapping of task
   descriptions to relative offsets is stored in `config/task_offsets.json`.
3. **Create Tasks in Clio:** For each calculated deadline, the script calls
   the Clio API to create a task assigned to the appropriate staff
   member.  Task names follow the format “Matter # – Task Description”.
   Due dates are set accordingly.  If a task already exists, it is
   updated instead of duplicated.
4. **Add to Calendar:** The script optionally adds events to the firm’s
   Google Calendar using the Google Calendar API.  This creates a
   calendar event for each task due date with reminders.  If the firm
   uses Motion, these events will sync to user calendars and be
   automatically scheduled.
5. **Log Results:** A summary of created or updated tasks is appended to
   a log file (`reports/task_generation.log`) and optionally sent via
   email to the responsible attorney.

## Manual Follow‑ups

- **Review Task List:** After tasks are generated, verify them in Clio
  Manage.  Adjust assignments or due dates if special circumstances
  apply.
- **Update Offsets:** If deadlines change (e.g. inspection period is
  extended), update `config/task_offsets.json` to reflect the new
  offsets and rerun the script.

## Updating This SOP

Changes to the task generation process—such as new task types or modified
offsets—should be documented here.  Commit SOP updates together with any
script or configuration changes.
