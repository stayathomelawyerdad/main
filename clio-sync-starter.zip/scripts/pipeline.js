// scripts/pipeline.js
function runWindow(startISO, endISO, dryRun) {
  const cfg = JSON.parse(PropertiesService.getScriptProperties().getProperty('BACKFILL_JSON') || '{"start": "2021-01-01", "end": "2025-09-06", "windowDays": 30, "gmailQueryTemplate": "after:{START} before:{END} (has:attachment OR label:To_File) -in:trash", "driveRoots": ["Clio_Inbox", "Client Files", "Scans"], "confidence": {"auto": 0.8, "review": 0.6}}');
  const sources = JSON.parse(PropertiesService.getScriptProperties().getProperty('SOURCES_JSON') || '{"gmail": {"labels": ["To_File", "Client", "Important"]}, "drive": {"roots": ["Clio_Inbox", "Client Files", "Scans"]}}');
  const gmailItems = fetchGmailWindow(startISO, endISO, sources.gmail.labels);
  const driveItems = fetchDriveWindow(startISO, endISO, sources.drive.roots);
  const items = gmailItems.concat(driveItems);
  const records = items.map(i => {
    const text = i.body || '';
    const firstAtt = (i.attachments && i.attachments[0]) ? i.attachments[0] : null;
    const extIds = [];
    if (i.messageId) extIds.push(i.messageId);
    if (i.driveId) extIds.push(i.driveId);
    const mapped = summarizeAndExtract(text, (firstAtt && firstAtt.name) || (i.subject || i.name || 'document'));
    if (firstAtt) mapped.sha256 = hashBytesB64(firstAtt.b64);
    mapped.externalIds = extIds;
    mapped.fileName = (firstAtt && firstAtt.name) || (i.subject || i.name || 'document');
    mapped.bytesB64 = firstAtt ? firstAtt.b64 : null;
    return mapped;
  });
  // Build plan (sanitized) and either return or execute
  const plan = planOps(records);
  // Publish to GitHub (sanitized) - placeholder
  // gitCommit('audits/dryrun-' + new Date().toISOString() + '.json', Utilities.base64Encode(JSON.stringify(plan,null,2)), 'chore: dry-run plan');
  if (dryRun) return plan;
  // TODO: execute plan via ClioClient
  return plan;
}
