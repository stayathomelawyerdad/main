// scripts/open-window-prs.js
const fs = require('fs');
const cp = require('child_process');
const windows = JSON.parse(fs.readFileSync('audits/windows.json','utf8'));
function sh(cmd){ cp.execSync(cmd, {stdio:'inherit'}); }
windows.forEach((w, i) => {
  const branch = `dryrun-${w.start}-to-${w.end}`;
  sh(`git checkout -b ${branch}`);
  fs.writeFileSync(`audits/dryrun-${w.start}-to-${w.end}.json`, JSON.stringify({window:w, plan:[]}, null, 2));
  sh(`git add audits/dryrun-${w.start}-to-${w.end}.json`);
  sh(`git commit -m "chore: dry-run plan ${w.start}..${w.end}"`);
  sh(`git push -u origin ${branch}`);
  sh(`gh pr create --title "Dry-Run ${w.start}..${w.end}" --body "Approve to execute Live for this window."`);
});
