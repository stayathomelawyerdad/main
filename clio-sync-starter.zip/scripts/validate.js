// scripts/validate.js
// Node version (for Actions) uses AJV; Apps Script can do basic checks.
function validateRecord(record, schema){
  // Minimal inline checks; full AJV runs in GitHub Action.
  if(!record || !record.document || !record.matter_core || !record.client) return false;
  if(!record.document.category || !record.document.summary) return false;
  return true;
}
