# SOP: New Client Intake & Matter Creation

**Last Updated:** 2025‑08‑16

## Purpose

This SOP describes how a new client intake in **Clio Grow** triggers an automated
sequence that creates contacts and a matter in **Clio Manage**, generates a folder
structure in Google Drive, sends a welcome email, and schedules tasks.  The goal
is to ensure a consistent, repeatable onboarding process for every new matter.

## Trigger

- **Event:** A prospective client submits an intake form in Clio Grow (or is
  converted from a lead to a client).
- **Automation:** A Zapier Zap named **Matter Intake Bootstrap** listens for the
  new lead event and initiates the workflow.

## Automated Steps

1. **Create or Update Contacts:** The Zap loops through the intake form
   respondents (primary client, spouse, other parties) and calls the Clio
   Manage API to either create a new contact or update an existing one.  Each
   contact is labeled appropriately (e.g. “Seller – John Doe”) and the Clio
   contact IDs are stored for later steps.
2. **Create the Matter:** Using the collected data, the Zap calls the Clio
   Manage API to create a new matter.  Required fields include the practice
   area, matter description (e.g. “2025‑08‑16 – Purchase of 123 Main St –
   John Doe”), responsible attorney or staff, and any custom fields (e.g.
   property address, closing date).  The matter number is saved for
   subsequent actions.
3. **Generate Folder Structure:** A separate script (or a Zap step) creates
   a folder in the firm’s Google Drive under the master “Matters” directory.
   Within the new matter folder, subfolders named `00_Admin` through
   `06_Closing` are created to standardize document organization.  This
   structure mirrors the firm’s manual filing system and is defined in
   `templates/folder_structure.md`.
4. **Send Welcome Email:** Zapier sends a templated welcome email to the
   client via Gmail.  The email uses a draft stored in the user’s Gmail
   account and populates placeholders with the client’s name, matter number,
   and a link to the client portal.  The sent email is automatically
   labeled (e.g. `Matters/Real Estate/Active/John Doe`) in Gmail for easy
   reference.
5. **Apply Task List:** If the matter type has a standard set of tasks
   (e.g. Real Estate Purchase tasks), the Zap assigns those tasks to the
   matter in Clio Manage.  Key dates from the intake form (e.g. inspection
   period, closing date) are used to set due dates.  These tasks appear on
   the firm’s calendar and, if synchronized, will show up in Motion for
   scheduling.
6. **Notify Team:** A final step sends a notification (via Slack or email)
   to the responsible attorney and staff with links to the new matter in
   Clio Manage and its folder in Google Drive.

## Manual Follow‑ups

- **Verify Data:** Confirm that all contact and matter fields were populated
  correctly in Clio Manage.  Fix any typos or missing information.
- **Review Engagement Letter:** Check the pre‑filled engagement letter in
  `00_Admin` and send it to the client for e‑signature via the firm’s
  signature tool (e.g. HelloSign).  Update the matter once the letter is
  signed.

## Updating This SOP

If you modify any part of the intake workflow—such as adding questions to the
Clio Grow form, changing custom fields, or updating the email template—edit
this document and commit the changes along with your code or Zap updates.
