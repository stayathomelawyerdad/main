# Clio Sync Runbook

## Purpose
Historical backfill and continuous sync from Gmail/Drive to Clio (Grow + Manage). Dry-Run → Approve → Live. Audit to GitHub.

## Quick Start
1. Create a **private** GitHub repo and push this project.
2. Enable Actions; add branch protection on `main`; enable secret scanning.
3. Add secrets:
   - `GITHUB_TOKEN` (provided automatically by Actions)
   - PAT (optional) for creating PRs via CLI if needed.
4. In Apps Script or Cloud Run, set script properties / secrets for:
   - `CLIO_CLIENT_ID`, `CLIO_CLIENT_SECRET`, `CLIO_BASE_URL`
   - Google OAuth done on first run
5. Configure `config/backfill.json`, `config/sources.json`, `config/mapping.json`.

## Backfill
Use the **Historical Backfill** workflow or run the pipeline per window from Apps Script.

## Approvals
Dry-Run artifacts are committed under `audits/`. Approve PR or comment `APPROVE` in the Check to execute Live.

## Rollback
Each Live window runs on its own branch under `runs/YYYY-MM`. Revert via PR; use `undo.json` if present.
