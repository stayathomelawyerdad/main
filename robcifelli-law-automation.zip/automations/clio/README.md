# Clio Customization and Field References

This directory contains reference material for Clio Grow and Clio Manage
customizations used by the firm.  Documenting these settings makes it easier
to integrate with Clio’s API and to keep field names and IDs consistent
across scripts and Zaps.

## Custom Fields

Create a Markdown file for each set of custom fields (e.g. `Real_Estate.md`)
that lists:

- The field label as it appears in Clio.
- The internal API name or slug (if available).
- The placeholder used in document templates.
- A brief description of the field’s purpose.

## Naming Conventions

Document any naming conventions used in Clio, such as how matter names are
formatted (e.g. “YYYY‑MM‑DD – Property – Client Name”) or how contacts are
labeled (“Role – Name”).

## Default Tasks and Workflows

If you use Clio’s built‑in task lists or workflows, list them here.  Include
the name of the task list, the tasks it contains, and any relative due date
offsets.  This makes it easier to sync the internal Python script with
Clio’s native automation.