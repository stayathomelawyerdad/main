# clio-sync (Alyssa)

Production-grade, backfill-first sync from Gmail/Drive → Clio (Grow + Manage). Uses Dry-Run → Approve → Live with GitHub as audit and control plane.

## What you get
- Historical sweep **2025-09-06 → 2021-01-01**
- Dedupe across Contacts/Matters/Documents
- Activities/Communications logged (no API noise)
- Sanitized logs/diffs/dashboards in **GitHub**
- Security hardening (private repo, signed commits, OIDC/Secrets)

## Start here
1. Create a **private** GitHub repo and upload this folder.
2. In Apps Script: paste files from `scripts/` (or run Cloud Run).
3. Add secrets (Clio + GitHub) and authorize Google.
4. Kick off a Dry-Run for the latest month; approve to execute Live.
