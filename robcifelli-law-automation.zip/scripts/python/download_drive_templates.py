#!/usr/bin/env python3
"""
download_drive_templates

Downloads templates from a designated Google Drive folder and stores them
in the `templates/` directory of this repository.  This script is intended
to run as part of a GitHub Action or manually when template updates are
needed.  It uses a service account for authentication.

Requirements:
    pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib

The following environment variables or config entries must be set:
    - DRIVE_TEMPLATES_FOLDER_ID: the ID of the folder containing templates.
    - GOOGLE_CREDENTIALS_JSON: JSON string for a service account credential.

Usage:
    python3 scripts/python/download_drive_templates.py
"""

import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload
from google.oauth2 import service_account


def load_config() -> Dict[str, Any]:
    config_path = Path(__file__).resolve().parents[2] / "config" / "settings.json"
    if config_path.exists():
        with config_path.open("r", encoding="utf-8") as f:
            return json.load(f)
    # Fallback to environment variables
    return {
        "DRIVE_TEMPLATES_FOLDER_ID": os.environ.get("DRIVE_TEMPLATES_FOLDER_ID"),
        "GOOGLE_CREDENTIALS_JSON": os.environ.get("GOOGLE_CREDENTIALS_JSON"),
    }


def get_service(creds_json: str):
    creds_info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(
        creds_info,
        scopes=["https://www.googleapis.com/auth/drive.readonly"],
    )
    return build("drive", "v3", credentials=creds)


def list_files(service, folder_id: str) -> List[Dict[str, Any]]:
    files: List[Dict[str, Any]] = []
    page_token = None
    query = f"'{folder_id}' in parents and trashed = false"
    while True:
        response = (
            service.files()
            .list(q=query, fields="nextPageToken, files(id, name, mimeType)", pageToken=page_token)
            .execute()
        )
        files.extend(response.get("files", []))
        page_token = response.get("nextPageToken")
        if not page_token:
            break
    return files


def download_file(service, file_id: str, name: str, dest_dir: Path) -> None:
    request = service.files().export_media(fileId=file_id, mimeType="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    dest_path = dest_dir / f"{name}.docx"
    with open(dest_path, "wb") as fh:
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        while not done:
            _, done = downloader.next_chunk()
    logging.info("Downloaded %s", dest_path)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    config = load_config()
    folder_id = config.get("DRIVE_TEMPLATES_FOLDER_ID")
    creds_json = config.get("GOOGLE_CREDENTIALS_JSON")
    if not folder_id or not creds_json:
        logging.error("Missing DRIVE_TEMPLATES_FOLDER_ID or GOOGLE_CREDENTIALS_JSON")
        sys.exit(1)
    try:
        service = get_service(creds_json)
        files = list_files(service, folder_id)
        dest_dir = Path(__file__).resolve().parents[2] / "templates"
        dest_dir.mkdir(exist_ok=True)
        for file in files:
            # Only export Google Docs; skip non‑Docs formats
            if file.get("mimeType") == "application/vnd.google-apps.document":
                download_file(service, file["id"], file["name"], dest_dir)
            else:
                logging.info("Skipping non‑Doc file: %s (%s)", file["name"], file["mimeType"])
    except HttpError as err:
        logging.error("Google Drive API error: %s", err)
        sys.exit(1)


if __name__ == "__main__":
    main()