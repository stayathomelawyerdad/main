// scripts/clio_client.js
// Placeholder: Apps Script-friendly HTTP client to Clio Manage + Grow
// Expand with actual endpoints, OAuth, retries, and idempotency headers.
function ClioClient() {
  const props = PropertiesService.getScriptProperties();
  const base = props.getProperty('CLIO_BASE_URL') || 'https://app.clio.com';
  const token = getClioAccessToken(); // implement OAuth refresh
  function req(path, method, payload, headers) {
    const url = base + path;
    const opts = {
      method: method || 'get',
      headers: Object.assign({
        'Authorization': 'Bearer ' + token,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }, headers || {}),
      muteHttpExceptions: true
    };
    if (payload) opts.payload = JSON.stringify(payload);
    const res = UrlFetchApp.fetch(url, opts);
    if (res.getResponseCode() >= 400) throw new Error('Clio error ' + res.getResponseCode() + ': ' + res.getContentText());
    return JSON.parse(res.getContentText());
  }
  return {
    findOrCreateContact: function(client){ /* TODO */ },
    findOrCreateMatter: function(contactId, matter){ /* TODO */ },
    attachDocument: function(matterId, name, bytesB64, category, externalIds){ /* TODO */ },
    createActivity: function(activity){ /* TODO */ },
    findMatterDocs: function(matterId, filter){ /* TODO */ }
  };
}
