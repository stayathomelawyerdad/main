# Zapier Automations

This folder contains documentation about the Zapier workflows used to glue
together Clio, Google Workspace, Motion, and other tools.  While Zapier
does not natively support version control, each Zap should be described here so
that its logic can be reviewed and maintained.

For each Zap, create a file named after the Zap (e.g. `Matter_Intake_Bootstrap.md`)
with the following sections:

1. **Name:** The Zap name in Zapier.
2. **Trigger:** What event triggers the Zap (e.g. “New Lead in Clio Grow”).
3. **Actions:** Each action step, in order, with a brief description (e.g.
   “Create Contact in Clio Manage”, “Create Matter”, “Send Email via Gmail”).
4. **Code Steps:** If the Zap includes JavaScript or Python code, save a copy
   of the code in this directory (e.g. `normalize_phone.js`) and link to it.
5. **Notes:** Any special considerations, such as filters, delays, or custom
   API calls.

Keeping this documentation up to date helps ensure that changes to the Zap
are reflected in the repository and that anyone can understand how the
automation works without logging into Zapier.