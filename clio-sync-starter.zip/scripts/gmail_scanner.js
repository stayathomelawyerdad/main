// scripts/gmail_scanner.js
function fetchGmailWindow(startISO, endISO, labels) {
  const start = startISO.replace(/-/g,'/');
  const end = endISO.replace(/-/g,'/');
  const labelQuery = (labels && labels.length) ? ' label:(' + labels.map(l=>'"'+l+'"').join(' OR ') + ')' : '';
  const q = `after:${start} before:${end} (has:attachment${labelQuery}) -in:trash`;
  const batch = [];
  let page = 0;
  const threads = GmailApp.search(q, page*100, 100);
  threads.forEach(t => t.getMessages().forEach(m => {
    batch.push({
      src: 'gmail',
      messageId: m.getHeader('Message-Id') || Utilities.getUuid(),
      ts: m.getDate().toISOString(),
      from: m.getFrom(), to: m.getTo(), cc: m.getCc(),
      subject: m.getSubject(),
      body: m.getPlainBody().slice(0, 20000),
      attachments: m.getAttachments({includeInlineImages:false, includeAttachments:true})
        .map(a => ({ name: a.getName(), mime: a.getContentType(), b64: Utilities.base64Encode(a.getBytes()) }))
    });
  }));
  return batch;
}
