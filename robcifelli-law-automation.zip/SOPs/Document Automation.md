# SOP: Document Automation and Template Management

**Last Updated:** 2025‑08‑16

## Purpose

This SOP outlines how the firm automates the creation of documents (such as
engagement letters, closing packets, and form letters) using data from Clio
and templates stored in Google Drive or Clio Grow.  It also describes how
templates are versioned and synchronized with this repository.

## Document Templates

Document templates live primarily in Google Drive for easy editing.  Each
template has a corresponding file in the `templates/` directory of this
repository to provide version control.  A scheduled GitHub Action (`sync-
drive.yml`) or an Apps Script (`AppsScript_SyncTemplates.gs`) periodically
downloads the latest templates and commits them to the `templates/` folder.

When editing a template:

1. **Edit in Google Docs** within the designated Drive folder (for
   example, `Drive/Templates/Engagement Letter`).
2. **Use placeholders** that correspond to fields in Clio or your custom
   variables (e.g. `{{ClientName}}`, `{{MatterDescription}}`, `{{ClosingDate}}`).
3. **Save changes** and allow the nightly synchronization to update the
   version in this repository.  Alternatively, run the Apps Script on
   demand.
4. **Commit the updated template** along with a clear commit message
   describing what changed (e.g. “Update engagement letter: add arbitration
   clause”).

## Automated Document Generation

Document automation is typically triggered after an intake or at specific
milestones (e.g. before closing).  The steps are:

1. **Assemble Data:** A Python script (`scripts/python/generate_document.py`)
   pulls client and matter data from Clio via API.  It also loads any
   additional data needed (e.g. from spreadsheets or form submissions).
2. **Merge with Template:** The script reads the relevant template (for
   example, `templates/Engagement Letter.docx`), replaces the placeholders
   with actual data, and generates a final document.
3. **Save and Upload:** The final document is saved as a PDF or DOCX in
   the matter’s Google Drive folder (e.g. `00_Admin`).  The script then
   attaches it to the Clio matter under Documents and optionally emails it
   to the client for review/signature.
4. **Log Generation:** The script logs the creation time, template name,
   and destination location in `reports/document_generation.log`.  This
   provides an audit trail and makes it easy to trace which version of a
   template was used.

## Manual Follow‑ups

- **Review the document** before sending it to the client.  Ensure that
  merged data is accurate and that no placeholders remain.
- **Update templates** as necessary when laws change or firm language
  evolves.  Version control ensures that you can reference prior versions
  if needed.

## Updating This SOP

Whenever you add a new template or modify the document automation process,
update this SOP and commit the changes with the relevant scripts.  Keep
template placeholders and field mappings consistent with `config/field-
mappings.csv`.
