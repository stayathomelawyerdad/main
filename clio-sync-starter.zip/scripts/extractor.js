// scripts/extractor.js
function summarizeAndExtract(text, filename){
  const prompt = [
    "You map legal content into EXISTING Clio fields FIRST.",
    "Return JSON with keys aligned to:",
    "- matter_core { number?, description?, status?, openDate?, closeDate?, practiceArea? }",
    "- client { name, emails[], phones[], address{} }",
    "- parties { buyer{}, seller{}, opposingCounsel{}, titleCompany{}, realtor{} }",
    "- real_estate { closingDate?, propertyAddress?, purchasePrice?, earnestMoneyDeposit1?, earnestMoneyDeposit2?, inspectionDeadline?, pin?, financingType?, loanOfficer?, titleFileNumber? }",
    "- probate { decedentsName?, decedentsDateOfDeath?, executor?, beneficiaries[] }",
    "- billing_snapshot { flatRate?, description?, openInvoiceNumber?, outstandingBalance? }",
    "- document { category, summary, communicationType? }",
    "Only fill fields present. Output strict JSON."
  ].join("\n");
  const out = callLLM(prompt + "\nFILENAME:"+ filename + "\n---\n" + text.substring(0, 8000));
  return JSON.parse(out);
}
function callLLM(prompt){
  // TODO: wire to your LLM endpoint (OpenAI/Vertex/Else). Keep PII safe.
  throw new Error("LLM not connected. Implement callLLM() to return JSON string.");
}
