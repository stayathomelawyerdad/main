// scripts/dedupe.js
function hashBytesB64(b64){
  const bytes = Utilities.base64Decode(b64);
  const dig = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
  return dig.map(b=>('0'+(b&0xFF).toString(16)).slice(-2)).join('');
}
function isDuplicateDoc(existingDocs, name, b64, externalIds){
  const sha = hashBytesB64(b64);
  return existingDocs.some(d => d.sha256 === sha || (d.external_ids||[]).some(x => externalIds && externalIds.indexOf(x) >= 0));
}
